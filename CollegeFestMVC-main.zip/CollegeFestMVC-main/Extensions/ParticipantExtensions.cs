namespace CollegeFestMVC.Extensions;

public static class ParticipantExtensions
{
    public static string GetRegistrationStatus(this Participant participant)
    {
        if (participant != null && participant.IsRegistered)
        {
            return "Confirmed";
        }
        return "Pending";
    }

    public static string GetFeeCategory(this Participant participant)
    {
        if (participant == null || !participant.RegistrationFee.HasValue || participant.RegistrationFee.Value == 0)
        {
            return "Free Event";
        }
        else if (participant.RegistrationFee.Value <= 200)
        {
            return "Standard Event";
        }
        else
        {
            return "Premium Event";
        }
    }
}
