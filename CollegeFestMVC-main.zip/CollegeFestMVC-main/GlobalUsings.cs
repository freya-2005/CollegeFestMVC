global using System;
global using System.Collections.Generic;
global using System.Linq;
global using Microsoft.AspNetCore.Mvc;
global using System.ComponentModel.DataAnnotations;
global using CollegeFestMVC.Models;
global using CollegeFestMVC.Extensions;
