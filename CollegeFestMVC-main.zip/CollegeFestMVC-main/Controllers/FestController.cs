namespace CollegeFestMVC.Controllers;

public class FestController : Controller
{
    private static readonly List<Participant> _participants = new()
    {
        new Participant
        {
            ParticipantId = 1,
            ParticipantName = "Aarav Sharma",
            Email = "aarav@example.com",
            Department = "Computer Science",
            Year = 3,
            EventName = "Code Sprint",
            IsTeamEvent = false,
            RegistrationFee = 0,
            IsRegistered = true
        },
        new Participant
        {
            ParticipantId = 2,
            ParticipantName = "Diya Patel",
            Email = "diya@example.com",
            Department = "Information Technology",
            Year = 2,
            EventName = "AI Hackathon",
            IsTeamEvent = true,
            RegistrationFee = 350,
            IsRegistered = true
        }
    };

    public IActionResult Welcome()
    {
        return View();
    }

    public IActionResult Index()
    {
        return View(_participants);
    }

    public IActionResult Register()
    {
        return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public IActionResult Register(Participant participant)
    {
        if (!ModelState.IsValid)
        {
            return View(participant);
        }

        participant.ParticipantId = _participants.Count > 0 
            ? _participants.Max(p => p.ParticipantId) + 1 
            : 1;

        if (participant.EventName.Contains("Hackathon", StringComparison.OrdinalIgnoreCase))
        {
            participant.RegistrationFee = 500;
        }
        else if (participant.EventName.Contains("Workshop", StringComparison.OrdinalIgnoreCase))
        {
            participant.RegistrationFee = 150;
        }
        else
        {
            participant.RegistrationFee = 0;
        }

        participant.IsRegistered = true;
        _participants.Add(participant);

        return RedirectToAction(nameof(Index));
    }

    public IActionResult Details(int id)
    {
        var participant = _participants.FirstOrDefault(p => p.ParticipantId == id);
        if (participant == null)
        {
            return NotFound();
        }
        return View(participant);
    }
}
