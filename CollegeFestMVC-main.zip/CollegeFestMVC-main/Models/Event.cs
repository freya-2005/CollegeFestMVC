namespace CollegeFestMVC.Models;

public class Event
{
    public int EventId { get; set; }

    [Required(ErrorMessage = "Event name is required.")]
    public string EventName { get; set; } = string.Empty;

    public int? MaximumParticipants { get; set; }

    [Range(0, 5000, ErrorMessage = "Fee must be non-negative.")]
    public decimal? RegistrationFee { get; set; }
}
